/**
 * 
 */
/**
 * 
 */
module Tekprog2 {
}