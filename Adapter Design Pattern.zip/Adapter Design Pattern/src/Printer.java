// Target Interface
interface Printer {
    void print(String document);
}
