// Adaptee
class LegacyPrinter {
    public void printDocument(String doc) {
        System.out.println("Legacy Printer: " + doc);
    }
}
