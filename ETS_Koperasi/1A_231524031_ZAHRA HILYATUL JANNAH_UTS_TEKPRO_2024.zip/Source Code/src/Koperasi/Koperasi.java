package Koperasi;

public interface Koperasi {

	public int LoanMonthly();
}
