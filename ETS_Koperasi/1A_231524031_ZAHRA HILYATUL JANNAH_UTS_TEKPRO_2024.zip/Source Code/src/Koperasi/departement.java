package Koperasi;

public class departement{
	private String depName;

	public String getDepName(String depName) {
		return depName;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}
	
}
