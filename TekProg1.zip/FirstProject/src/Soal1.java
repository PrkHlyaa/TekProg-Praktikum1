
public class Soal1 {

	public static void main(String[] args) {
		byte angka1 = 125;
		byte angka2 = 6;
		byte hasil = (byte) (angka1+angka2);
		
		System.out.println("Hasil = " +hasil);

	}

}
