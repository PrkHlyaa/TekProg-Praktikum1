
public interface KeyboardInput {
    boolean isKeyDown(char key);
    void setKeyDown(char key, boolean down);
}
